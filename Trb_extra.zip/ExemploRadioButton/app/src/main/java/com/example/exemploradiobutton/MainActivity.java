package com.example.exemploradiobutton;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private CheckBox cbRefri;
    private CheckBox cbBorda;
    private Spinner spSabores;
    private ListView lvSabores;
    private int nrSabores;
    private double vlTotal;
    private double vlTamanho;
    private double vlAdicional;
    private ArrayList<String> list;
    private String tamanho = "";
    private TextView tvPedido;
    private TextView tvValor;
    private ArrayAdapter adapter;
    private String adicionais = "";
    private Button btRemover;
    private Button btLimpar;
    private Button btConcluir;
    private int selectedPosition = -1;
    private RadioButton rbMedia;
    private RadioButton rbGrande;
    private RadioButton rbPequena;
    private RadioGroup radioGroup;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cbRefri = findViewById(R.id.cbRefri);
        cbBorda = findViewById(R.id.cbBorda);
        spSabores = findViewById(R.id.spSabores);
        lvSabores = findViewById(R.id.lvSabores);
        tvPedido = findViewById(R.id.tvPedido);
        btConcluir = findViewById(R.id.btConcluir);
        btLimpar = findViewById(R.id.btLimpa);
        btRemover = findViewById(R.id.btRemove);
        tvValor = findViewById(R.id.tvValor);
        list = new ArrayList<String>();
        rbMedia = findViewById(R.id.rbMedia);
        rbGrande = findViewById(R.id.rbGrande);
        rbPequena = findViewById(R.id.rbPequena);
        radioGroup = findViewById(R.id.rdGroup);

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(this, R.array.spinner_items, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spSabores.setAdapter(spinnerAdapter);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        lvSabores.setAdapter(adapter);

        spSabores.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int i, long id) {
                if (validaTamanho() == true) {
                    String selectedItem = parent.getItemAtPosition(i).toString();
                    list.add(selectedItem);
                    adapter.notifyDataSetChanged();
                    montarPedido();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        cbRefri.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (cbRefri.isChecked()) {
                    adicionais += " Refri";
                } else if (cbBorda.isChecked() && cbRefri.isChecked() == false) {
                    adicionais = "";
                    adicionais += " Borda";
                } else {
                    adicionais = "";
                }

                montarPedido();
            }
        });
        cbBorda.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (cbBorda.isChecked()) {
                    adicionais += " Borda";
                } else if (cbRefri.isChecked() && cbBorda.isChecked() == false) {
                    adicionais = "";
                    adicionais += " Refri";
                } else {
                    adicionais = "";
                }
                montarPedido();
            }
        });

        lvSabores.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedPosition = position;
            }
        });

        btRemover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedPosition != -1) {
                    list.remove(selectedPosition);
                    adapter.notifyDataSetChanged();
                    selectedPosition = -1;
                    montarPedido();
                }
            }
        });

        btConcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cbBorda.setChecked(false);
                cbRefri.setChecked(false);
                radioGroup.clearCheck();
                tvPedido.setText("Seu pedido:\n");
                tvValor.setText("Total do pedido: R$");
                adapter.clear();
                adapter.notifyDataSetChanged();
                vlTotal = 0;
                vlAdicional = 0;
                vlTamanho = 0;
                Toast.makeText(MainActivity.this, "O pedido de valor: " + vlTotal + " foi concluido.", Toast.LENGTH_LONG).show();
            }
        });

        btLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cbBorda.setChecked(false);
                cbRefri.setChecked(false);
                radioGroup.clearCheck();
                tvPedido.setText("Seu pedido:\n");
                tvValor.setText("Total do pedido: R$");
                adapter.clear();
                adapter.notifyDataSetChanged();
                vlTotal = 0;
                vlAdicional = 0;
                vlTamanho = 0;
            }
        });


    }


    public void selecionarOpcao(View view) {
        boolean selecionado = ((RadioButton) view).isChecked();

        switch (view.getId()) {
            case R.id.rbGrande:
                if (selecionado) {
                    vlTamanho = 40;
                    tamanho = "Grande";
                    adapter.clear();
                    adapter.notifyDataSetChanged();
                    montarPedido();
                }
                break;
            case R.id.rbMedia:
                if (selecionado) {
                    vlTamanho = 30;
                    tamanho = "Média";
                    adapter.clear();
                    adapter.notifyDataSetChanged();
                    montarPedido();
                }
                break;
            case R.id.rbPequena:
                if (selecionado) {
                    vlTamanho = 20;
                    tamanho = "Pequena";
                    adapter.clear();
                    adapter.notifyDataSetChanged();
                    montarPedido();
                }
                break;
        }
    }

    public void montarPedido() {
        ArrayList<String> valoresDaListView = new ArrayList<>();

        for (int i = 0; i < adapter.getCount(); i++) {
            String valor = adapter.getItem(i).toString();
            valoresDaListView.add(valor);
        }
        String pedido = "Seu pedido: " +" \n Tamanho: " + tamanho + "\n Sabores: " + valoresDaListView.toString() + "\n Adicionais: " + adicionais;
        tvPedido.setText("");
        tvPedido.setText(pedido);
        tvValor.setText("Total do pedido: R$ " + getVlrTotal());
    }

    public double getVlrTotal() {
        double vlAdicional = 0;

        if (cbBorda.isChecked()) {
            vlAdicional += 10;
        }

        if (cbRefri.isChecked()) {
            vlAdicional += 5;
        }

        return vlTotal = vlAdicional + vlTamanho;
    }

    public boolean validaTamanho() {
        if (tamanho.equals("GG") && adapter.getCount() >= 4) {
            Toast.makeText(this, "Só é possivel selecionar 4 sabores para o tamanho Grande", Toast.LENGTH_LONG).show();
            return false;
        } else if (tamanho.equals("M") && adapter.getCount() >= 2) {
            Toast.makeText(this, "Só é possivel selecionar 2 sabores para o tamanho Médio", Toast.LENGTH_LONG).show();
            return false;
        } else if (tamanho.equals("P") && adapter.getCount() >= 1) {
            Toast.makeText(this, "Só é possivel selecionar 1 sabores para o tamanho Pequeno", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

}